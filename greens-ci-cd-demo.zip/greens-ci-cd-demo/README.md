# simple-docker-image
Simple static HTML page in a Docker image
